-- 1. Show my full profile
SELECT * FROM profile;
-- 2. My movies in rank order (sorting)
SELECT title, release_year FROM movie ORDER BY my_rank;
-- 3. Only movies released after 2010 (filtering)
SELECT title FROM movie WHERE release_year > 2010;
-- 4. Combine tables: my name with each of my hobbies (relationship)
SELECT profile.full_name, hobby.hobby_name
FROM profile
JOIN hobby ON hobby.profile_id = profile.profile_id;
-- 5. How many skills do I list?
SELECT COUNT(*) FROM skill;
