PRAGMA foreign_keys = ON;

CREATE TABLE profile (
  profile_id INTEGER PRIMARY KEY,
  full_name TEXT NOT NULL,
  programme TEXT,
  bio TEXT
);
CREATE TABLE skill (
  skill_id INTEGER PRIMARY KEY,
  profile_id INTEGER NOT NULL,
  skill_name TEXT NOT NULL,
  level TEXT,
  FOREIGN KEY (profile_id) REFERENCES profile(profile_id)
);
CREATE TABLE hobby (
  hobby_id INTEGER PRIMARY KEY,
  profile_id INTEGER NOT NULL,
  hobby_name TEXT NOT NULL,
  description TEXT,
  FOREIGN KEY (profile_id) REFERENCES profile(profile_id)
);
CREATE TABLE movie (
  movie_id INTEGER PRIMARY KEY,
  profile_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  release_year INTEGER,
  my_rank INTEGER,
  why_i_love_it TEXT,
  FOREIGN KEY (profile_id) REFERENCES profile(profile_id)
);
CREATE TABLE enquiry (
  enquiry_id INTEGER PRIMARY KEY,
  profile_id INTEGER NOT NULL,
  sender_name TEXT NOT NULL,
  sender_email TEXT NOT NULL,
  message TEXT NOT NULL,
  sent_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (profile_id) REFERENCES profile(profile_id)
);

INSERT INTO profile (full_name, programme, bio)
VALUES ('Finley Wilber Otieno Omondi', 'BSc Environmental Science',
 'Second-year Environmental Science student at JKUAT who wants to become an environmental scientist.');

INSERT INTO skill (profile_id, skill_name, level) VALUES
 (1, 'Communication', 'Advanced'),
 (1, 'Problem solving', 'Advanced'),
 (1, 'Adaptability', 'Advanced'),
 (1, 'Teamwork', 'Advanced'),
 (1, 'Leadership', 'Advanced'),
 (1, 'Public speaking', 'Intermediate'),
 (1, 'Computer literacy', 'Intermediate'),
 (1, 'Data entry and analysis in Excel', 'Intermediate'),
 (1, 'Field species identification', 'Intermediate'),
 (1, 'Chemistry laboratory skills', 'Intermediate');

INSERT INTO hobby (profile_id, hobby_name, description) VALUES
 (1, 'Swimming', '10 years. Helps me relax, stay active and challenge myself.'),
 (1, 'Travelling', 'About 5 years. Best moment: my trip to Dubai.'),
 (1, 'Driving', 'About 1 year. Best moment: my first successful solo drive.');

INSERT INTO movie (profile_id, title, release_year, my_rank, why_i_love_it) VALUES
 (1, 'Money Heist', 2017, 1, 'Strategy, teamwork and thinking ahead.'),
 (1, 'Teen Wolf', 2011, 2, 'Loyalty, courage and friendship are forms of strength.'),
 (1, 'Fast & Furious', 2001, 3, 'Family is built on loyalty, trust and showing up.'),
 (1, 'The Blacklist', 2013, 4, 'Intelligence and patience can beat force.'),
 (1, 'Polygamist', 2026, 5, 'Honesty, commitment and accountability in relationships.');
